import Image from 'next/image'

import TestimonialImage01 from '@/public/images/testimonial-01.jpg'
import TestimonialImage02 from '@/public/images/testimonial-02.jpg'
import TestimonialImage03 from '@/public/images/testimonial-03.jpg'

export default function Testimonials() {
  return (
    <section>
      <div className="max-w-6xl px-4 mx-auto sm:px-6">
        <div className="py-12 border-t border-gray-800 md:py-20">

          {/* Section header */}
          <div className="max-w-3xl pb-12 mx-auto text-center md:pb-20">
            <h2 className="mb-4 h2">Notre équipe</h2>
            {/* <p className="text-xl text-gray-400">Vitae aliquet nec ullamcorper sit amet risus nullam eget felis semper quis lectus nulla at volutpat diam ut venenatis tellus—in ornare.</p> */}
          </div>

          {/* Testimonials */}
          <div className="grid items-start max-w-sm gap-8 mx-auto lg:grid-cols-3 lg:gap-6 lg:max-w-none">

            {/* 1st testimonial */}
            <div className="flex flex-col h-full p-6 bg-gray-800" data-aos="fade-up">
              <div>
                <div className="relative inline-flex flex-col mb-4">
                  <Image className="rounded-full" src={TestimonialImage01} width={150} height={48} alt="Testimonial 01" />
                 
                </div>
              </div>
              <blockquote className="text-lg text-gray-400 grow">— Open PRO lets me quickly get the insights I care about so that I can focus on my productive work. I've had Open PRO for about 24 hours now and I honestly don't know how I functioned without it before.</blockquote>
              <div className="pt-5 mt-6 font-medium text-gray-700 border-t border-gray-700">
                <cite className="not-italic text-gray-200">Anastasia Dan</cite> - <a className="text-red-600 transition duration-150 ease-in-out hover:text-gray-200" href="#0">UX Board</a>
              </div>
            </div>

            {/* 2nd testimonial */}
            <div className="flex flex-col h-full p-6 bg-gray-800" data-aos="fade-up" data-aos-delay="200">
              <div>
                <div className="relative inline-flex flex-col mb-4">
                  <Image className="rounded-full" src={TestimonialImage02} width={150} height={48} alt="Testimonial 02" />
                 
                </div>
              </div>
              <blockquote className="text-lg text-gray-400 grow">— Open PRO lets me quickly get the insights I care about so that I can focus on my productive work. I've had Open PRO for about 24 hours now and I honestly don't know how I functioned without it before.</blockquote>
              <div className="pt-5 mt-6 font-medium text-gray-700 border-t border-gray-700">
                <cite className="not-italic text-gray-200">Anastasia Dan</cite> - <a className="text-red-600 transition duration-150 ease-in-out hover:text-gray-200" href="#0">UX Board</a>
              </div>
            </div>

            {/* 3rd testimonial */}
            <div className="flex flex-col h-full p-6 bg-gray-800" data-aos="fade-up" data-aos-delay="400">
              <div>
                <div className="relative inline-flex flex-col mb-4">
                  <Image className="rounded-full" src={TestimonialImage03} width={150} height={48} alt="Testimonial 03" />
                 
                </div>
              </div>
              <blockquote className="text-lg text-gray-400 grow">— Open PRO lets me quickly get the insights I care about so that I can focus on my productive work. I've had Open PRO for about 24 hours now and I honestly don't know how I functioned without it before.</blockquote>
              <div className="pt-5 mt-6 font-medium text-gray-700 border-t border-gray-700">
                <cite className="not-italic text-gray-200">Anastasia Dan</cite> - <a className="text-red-600 transition duration-150 ease-in-out hover:text-gray-200" href="#0">UX Board</a>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  )
}
