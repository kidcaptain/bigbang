export default function Blocks() {
  return (
    <section>
      <div className="max-w-6xl px-4 mx-auto sm:px-6">
        <div className="py-12 border-t border-gray-800 md:py-20">

          {/* Section header */}
          <div className="max-w-3xl pb-12 mx-auto text-center md:pb-20">
            <p className="text-xl text-gray-400">Facile et Effective, nous réalisons vos projets rapidement et à moindre coût.</p>
          </div>

          {/* Items */}
          <div className="grid items-start max-w-sm gap-8 mx-auto md:grid-cols-2 lg:grid-cols-3 lg:gap-16 md:max-w-2xl lg:max-w-none" data-aos-id-blocks>

            {/* 1st item */}
            <div className="relative flex flex-col items-center" data-aos="fade-up" data-aos-anchor="[data-aos-id-blocks]">
              <h4 className="mb-2 text-red-600 h4">Service Rapide</h4>
              <p className="text-sm text-left text-gray-400">Rapide et Efficace, nos services sont toujours d'une grande qualité pour satisfaire à tous vos besoins.</p>
            </div>

            {/* 2nd item */}
            <div className="relative flex flex-col items-center" data-aos="fade-up" data-aos-delay="100" data-aos-anchor="[data-aos-id-blocks]">
              <h4 className="mb-2 text-red-600 h4 ">Une Équipe d'expert</h4>
              <p className="text-sm text-left text-gray-400">Nos Équipes professionnels et qualifié, répondent à tous vos besoins dans les plus délais.</p>
            </div>

            {/* 3rd item */}
            <div className="relative flex flex-col items-center" data-aos="fade-up" data-aos-delay="200" data-aos-anchor="[data-aos-id-blocks]">
             
              <h4 className="mb-2 text-red-600 h4">Garantie assurée</h4>
              <p className="text-sm text-left text-gray-400">Nous vous assurons une garantie de 03 mois sur tous nos services frais payé pour tous vos besoins de qualité.</p>
            </div>

            {/* 4th item */}
            <div className="relative flex flex-col items-center" data-aos="fade-up" data-aos-delay="300" data-aos-anchor="[data-aos-id-blocks]">
              <h4 className="mb-2 text-red-600 h4">Un suivi de qualité</h4>
              <p className="text-sm text-left text-gray-400">Obtenez rapidement un suivi optimale et de qualité sur tous vos projets de référence.</p>
            </div>

            {/* 5th item */}
            <div className="relative flex flex-col items-center" data-aos="fade-up" data-aos-delay="400" data-aos-anchor="[data-aos-id-blocks]">
              <h4 className="mb-2 text-red-600 h4">Services à moindre coût</h4>
              <p className="text-sm text-left text-gray-400">Parce nous savons que vous aimez faire des économies, nos services sont adaptés à votre budget pour vous permettre de profiter en toute tranquillité de nos offres hors du commun.</p>
            </div>

          </div>

        </div>
      </div>
    </section>
  )
}
