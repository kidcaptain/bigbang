import Link from 'next/link'
import MobileMenu from './mobile-menu'
import logo from '@/public/images/logo.png'

export default function Header() {

  return (
    <header className="absolute z-30 w-full">
      <div className="max-w-6xl px-4 mx-auto sm:px-6">
        <div className="flex items-center justify-between h-20">
          {/* Site branding */}
          <div className="mr-4 shrink-0">
            {/* Logo */}
            <Link href="/" className="block" aria-label="Cruip">
              <img src={logo.src} width={48} alt="Testimonial 03"></img>
            </Link>
          </div>

          {/* Desktop navigation */}
          <nav className="hidden md:flex md:grow">
            {/* Desktop sign in links */}
            <ul className="flex flex-wrap items-center justify-end grow">
              <li>
                <a
                  href="#hero"
                  className="flex items-center px-4 py-3 font-medium text-red-600 transition duration-150 ease-in-out hover:text-gray-200"
                >
                 Accueil
                </a>
              </li>
              <li>
                <a
                  href="#service"
                  className="flex items-center px-4 py-3 font-medium text-red-600 transition duration-150 ease-in-out hover:text-gray-200"
                >
                  Services
                </a>
              </li>
              <li>
                <a
                  href="#produit"
                  className="flex items-center px-4 py-3 font-medium text-red-600 transition duration-150 ease-in-out hover:text-gray-200"
                >
                  Produits
                </a>
              </li>
              <li>
                <button className="ml-3 text-white bg-black btn-sm hover:bg-stone-700">
                  Anglais
                </button>
              </li>
            </ul>
          </nav>

          <MobileMenu />

        </div>
      </div>
    </header>
  )
}
