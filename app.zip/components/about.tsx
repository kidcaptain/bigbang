'use client'
import "./about.css";

export default function About() {
    return (
        <>
            <div className="relative " id="about" >
                <div style={{ zIndex: 5, position: "relative" }}>
                    <div>
                        <div>
                                <div style={{ padding: "70px" }} className="m-auto lg:bg-gray-900 bg-gray-900/20 lg:w-1/2 ">
                                    <h2 className="mb-4 text-center h2">A propos</h2>
                                    <p className="my-4 text-xl text-center text-gray-400"> Qui sommes-nous?</p>
                                    <p className="text-lg text-justify text-gray-400">
                                        Nous sommes une entreprise de prestation de services informatiques,
                                        plus précisement dans la conception de site web,
                                        d'application mobile et winform, dans l'infographie et la formation. Basée à Yaoundé(Cameroun), nous intervenons auprès
                                        de nombreux organismes locaux et internationaux dans l'optique de les accompagner en mettant à leur disposition des
                                        solutions innovantes à la pointe de la technologie moderne.
                                    </p>
                                </div>
                        </div>
                    </div>
                </div>
                <div
                    style={{
                        backgroundColor: "black",
                        opacity: 0.7,
                        width: "100%",
                        height: "100%",
                        position: "absolute",
                        top: 0,
                        left: 0,
                        zIndex: 1
                    }}
                ></div>
            </div>
        </>
    )
}
